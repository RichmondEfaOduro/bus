import axios from "axios";

export const getBusLines = async (req, res, next) => {
    const requestURL = `https://api.sl.se/api2/LineData.json?model=jour&key=${process.env.SL_API_KEY}&DefaultTransportModeCode=BUS`;
    console.log('requestURL: ', requestURL);
    const response = await axios
      .get(requestURL)
      .then((data) => {
        return data.data.ResponseData.Result;
      })
      .catch((error) => console.log(error));
      console.log('response: ', response);
    req.busLines = response;
  next();
};