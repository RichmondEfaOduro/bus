import express from "express";
import cors from "cors";
import dotenv from "dotenv";
import BusLines from './routes/busLines.js';

const app = express();
app.use(express.json());
app.use(cors());
dotenv.config();

app.use('/api/v1/', BusLines)

const PORT = process.env.PORT || 8080;

app.listen(PORT, () => {
  console.log(`Server running on port: ${PORT}`);
});