import React, { useState, useEffect } from 'react';
import './App.css';

function App() {
  const [busLines, setBusLines] = useState<any>();

  useEffect(() => {
    fetchData();
  }, [])

  const fetchData = async () => {
    const requestURL = `http://localhost:8080/api/v1/busLines`;
    const data = 
      await fetch(requestURL)
      .then((response) => response.json())
      .catch(error => console.log('error: ', error));
      console.log('data: ', data);
  }

  return (
    <div className="App">
      hello world
    </div>
  );
}

export default App;
