## Before running the project

In order to run the project you NEED to:

1. Run 'NPM install'
2. Navigate to: "/client"
3. Run 'NPM install'
4. create a .env file in the root of the project
5. Add the environment variable: SL_API_KEY=KEY

## To run the app

1. Start in the root of the project and run "npm start"
2. open a new terminal and in that terminal navigate to the client folder and run "npm start"

## Available scripts

To start the app

### `npm start`

Runs the app in the development mode.\
Open [http://localhost:3000](http://localhost:3000) to view it in the browser.


